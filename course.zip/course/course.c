/**
 * @file course.c
 * @author Samir Matani (matans1@mcmaster.ca)
 * @brief File pertaining to course functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This function will take both a course and a student, and it will register a student in whatever course is presented
 * 
 * @param course This parameter indicates the course that the students will be registered in
 * @param student This parameter indicates the students who will be registered in the presented course
 */

void enroll_student(Course *course, Student *student)
{
  // Increases the total number of students by 1
  course->total_students++;
  // Calloc will create an array that contains the memory of one student if there is only one student.
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  // If there is more than one student than realloc will add another student into the course
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This is the print function, and it will output the name of the course, the course code, and the names of all the students in that course.
 * 
 * @param course This parameter indicates the course that the students will be registered in
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");

  // This will loop through and will print all the students registered in the course.
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief This functions take the averages of all the students in a given course and returns the name of the student who has the highest average
 * 
 * @param course This parameter indicates the course that the students will be registered in
 * @return Student*  Name of student with the highest average
 */

Student* top_student(Course* course)
{
// If there are no students in the course, then NULL is returned
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 /* Otherwise, this will loop through the students in the course, take their averages
    and will return the student with the highest average*/
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function returns the students passing the course as an array 
 * 
 * @param course This parameter indicates the course that the students will be registered in
 * @param total_passing The number of students who are passing the course
 * @return Student* 
 */

Student *passing(Course* course, int *total_passing)
{
  
  int count = 0;
  Student *passing = NULL;
  /* This will loop through all the students and will 
  increase the count for the students who are passing*/
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  /* This will add all students who are passing into an array
  and then it will return the array*/
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}