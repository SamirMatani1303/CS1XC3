/**
 * @file student.c
 * @author Samir Matani (matans1@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This function will take a student and a grade, and it will add the grade to the student's grades
 * 
 * @param student The name of the student who was inputted
 * @param grade The grade that will be added to the student's grades.
 */

void add_grade(Student* student, double grade)
{
  /* If this is the first grade of the student, then calloc is used and will create an array
  for that student with one grade, otherwise realloc will add the grade to the student's grades*/
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This function will take a given student and return the average of that student's grades
 * 
 * 
 * @param student The name of the student who was inputted
 * @return double: This is the average grade of the student
 */

double average(Student* student)
{
  // return 0 if there are no grades for that student
  if (student->num_grades == 0) return 0;

  // else it will go through the students grades and add them up, and then it will divide by the total.
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**
 * @brief This is a function used for printing that will print the student's name, ID, Grades, and their average
 * 
 * @param student The name of the student who was inputted
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // loop through the students grades to print them
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function will take a random student by taking a random first and last name, 
 * along with a random ID, and it will take their grades an as input, and it will average them
 * 
 * @param grades A random number of grades 
 * @return Student* This will return the random student generated
 */

Student* generate_random_student(int grades)
{
  // takes random first name out of the 24 options
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  // takes random last name out of the 24 options
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // creates a random student id by looping though 9 numbers and taking random ones
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /* this will take the number of inputted grades and adds a set of random grades 
  ranging from 25-100 to that inputted number*/
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}